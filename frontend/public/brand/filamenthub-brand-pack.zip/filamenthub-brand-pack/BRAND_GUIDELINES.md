# FilamentHub brand resources

Display name: FilamentHub

## Logo

Use the supplied SVG files when possible. Transparent PNG files are also provided.
- `logos/logo.svg`: the original white FilamentHub mark.
- `logos/logo-dark.svg` and `.png`: white mark for dark backgrounds.
- `logos/logo-light.svg` and `.png`: deep purple mark for light backgrounds.
- `logos/icon.svg` and `.png`: square icon with the same mark.

## Colors

- Purple: #7C3AED — RGB 124, 58, 237
- Deep purple: #3B0764 — RGB 59, 7, 100
- White: #FFFFFF — RGB 255, 255, 255

## Usage

Please use the supplied official files, preserve the mark's proportions, leave sufficient space around it, and choose a version with good contrast.

Please do not stretch or distort the mark, recolor or alter its elements, or add effects, outlines or shadows that change its appearance.
